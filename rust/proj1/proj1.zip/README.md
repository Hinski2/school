# Jakub Iliński Porjekt Fraktal

---


### Odpalanie projektu
``` bash
cargo run --release /img/img0.bmp
cargo run --release /img/img0.bmp -2 2 1000 -2 2 1000 100
```

### testowanie projektu 
``` bash 
cargo test --release
```